
				Pixel Art created by Vicente Nitti (@vnitti)

			Thank you for using: "GLACIAL MOUNTAINS: PARALLAX BACKGROUND"

=== CONTENT ===
cloud_lonely.png
clouds_bg.png
clouds_mg_1.png
clouds_mg_1_lightened.png
clouds_mg_2.png
clouds_mg_3.png
glacial_mountains.png
glacial_mountains_lightened.png
sky.png
sky_lightened.png
background_glacial_mountains.png (384x216 px)
background_glacial_mountains_lightened.png (384x216 px)
GlacialMountains_PS.psd
Glacial_Mountains-Cover.png
Readme.txt



=== LICENSE ===
This pixel art piece is licensed under a Creative Commons Atribution 4.0 International license CC BY 4.0,
which reads the following:

You are free to:
	+ Share � copy and redistribute the material in any medium or format
	+ Adapt � remix, transform, and build upon the material for any purpose, even commercially.

Under the following terms:
	+ Attribution � You must give appropriate credit, provide a link to the license, and indicate if
	  changes were made. You may do so in any reasonable manner, but not in any way that suggests the
	  licensor endorses you or your use.

	+ No additional restrictions � You may not apply legal terms or technological measures that legally
	  restrict others from doing anything the license permits.

License - http://creativecommons.org/licenses/by/4.0/

You are not required to credit this asset if you paid for it. However it will be greatly appreciated.



=== FIND ME ON ===
Twitter:   twitter.com/vnitti_art
Itch.io:     vnitti.itch.io/
Portfolio:  behance.net/vnitti
                artstation.com/vnitti
                deviantart.com/vnitti


				Have a good developing! - Vicente Nitti